import json
import csv

json_list = []

with open('worldGDPc.csv','r') as f:
    for row in csv.DictReader(f):
        json_list.append(row)


with open('worldGDPj.json','w') as f:
    json.dump(json_list,f)


with open ('worldGDPj.json','r') as f:
    json_output = json.load(f)
    
